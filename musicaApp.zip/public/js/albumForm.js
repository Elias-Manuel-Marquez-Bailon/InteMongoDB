const form = document.getElementById('albumForm');
const fileUploadArea = document.getElementById('fileUploadArea');
const coverImageInput = document.getElementById('coverImageInput');
const coverPreview = document.getElementById('coverPreview');
const songsContainer = document.getElementById('songsContainer');
const addSongBtn = document.getElementById('addSongBtn');
const submitBtn = form.querySelector('button[type="submit"]');

let currentAlbumId = null;

// ===== Funciones principales =====

// Manejo de la subida de imagen
function handleImagePreview() {
    const file = coverImageInput.files[0];
    if (file) {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            coverPreview.src = e.target.result;
            coverPreview.style.display = 'block';
        };
        
        reader.readAsDataURL(file);
    } else {
        coverPreview.src = '#';
        coverPreview.style.display = 'none';
    }
}

// Manejo de canciones
function createSongInput(index = null) {
    const div = document.createElement('div');
    div.className = 'song-input';

    const input = document.createElement('input');
    input.type = 'text';
    input.name = 'songs[]';
    input.required = true;
    input.placeholder = `Canción ${index !== null ? index + 1 : ''}`;

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'removeSongBtn';
    removeBtn.textContent = '🗑️';
    removeBtn.addEventListener('click', () => {
        div.remove();
        updateSongPlaceholders();
    });

    div.appendChild(input);
    div.appendChild(removeBtn);
    return div;
}

function updateSongPlaceholders() {
    const inputs = songsContainer.querySelectorAll('input[name="songs[]"]');
    inputs.forEach((input, i) => {
        input.placeholder = `Canción ${i + 1}`;
    });
}

function addInitialSong() {
    songsContainer.appendChild(createSongInput(0));
}

function resetForm() {
    form.reset();
    coverPreview.src = '#';
    coverPreview.style.display = 'none';
    songsContainer.innerHTML = '';
    addInitialSong();
    coverImageInput.value = '';
    currentAlbumId = null;
}

// ===== Event Listeners =====

fileUploadArea.addEventListener('click', () => coverImageInput.click());
coverImageInput.addEventListener('change', handleImagePreview);

addSongBtn.addEventListener('click', () => {
    const songInputs = songsContainer.querySelectorAll('.song-input');
    songsContainer.appendChild(createSongInput(songInputs.length));
});

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Mostrar estado de carga
    const originalBtnText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Enviando...';
  
    try {
        const formData = new FormData(form);
        const response = await fetch('/newalbum', {
            method: 'POST',
            body: formData
        });
    
        if (response.ok) {
            const result = await response.json();
            alert(result.message || 'Álbum creado exitosamente');
            resetForm();
    
            if (typeof loadAlbums === 'function') {
                loadAlbums();
            }
        } else {
            const error = await response.json();
            throw new Error(error.message || 'Error al crear el álbum');
        }
    } catch (error) {
        console.error('Error:', error);
        alert(error.message || 'Error al procesar la solicitud');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalBtnText;
    }
});

// Inicialización
window.addEventListener('DOMContentLoaded', addInitialSong);